# Sandooo Research Mode

This document explains how to use the research mode of the Sandooo MEV bot, which allows you to analyze sandwich opportunities without executing transactions or sending Telegram notifications.

## What is Research Mode?

Research mode is a modified version of the Sandooo bot that:

- ✅ **Analyzes** sandwich opportunities in real-time
- ✅ **Simulates** transactions and bundles
- ✅ **Logs** all findings to console
- ✅ **Does NOT execute** any actual transactions
- ✅ **Does NOT send** Telegram notifications
- ✅ **Does NOT require** private keys or bot addresses

## Use Cases

Research mode is perfect for:

- **Academic research** on MEV and sandwich attacks
- **Strategy development** and backtesting
- **Market analysis** without financial risk
- **Learning** how MEV bots work
- **Testing** new optimization algorithms

## How to Enable Research Mode

### 1. Set Environment Variable

```bash
export RESEARCH_MODE=true
```

Or add to your `.env` file:

```env
RESEARCH_MODE=true
```

### 2. Run the Bot

```bash
cargo run
```

The bot will automatically detect the `RESEARCH_MODE` environment variable and start in research mode.

## Environment Variables for Research Mode

Research mode only requires these environment variables:

```env
# Required
HTTPS_URL=https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY
WSS_URL=wss://eth-mainnet.g.alchemy.com/v2/YOUR_KEY

# Optional
DEBUG=false
```

**Note:** You do NOT need:
- `PRIVATE_KEY`
- `BOT_ADDRESS`
- `IDENTITY_KEY`
- `TELEGRAM_TOKEN`
- `TELEGRAM_CHAT_ID`
- `USE_ALERT`

## What Happens in Research Mode

### 1. **Transaction Monitoring**
- Monitors pending transactions in the mempool
- Identifies potential sandwich opportunities
- Logs all findings with `[RESEARCH]` prefix

### 2. **Sandwich Analysis**
- Runs the same appetizer logic to identify opportunities
- Simulates sandwich execution without actual execution
- Calculates potential profits and gas costs
- Logs detailed analysis results

### 3. **Bundle Simulation**
- Creates dummy transaction bundles for analysis
- Simulates bundle execution (no actual broadcast)
- Logs bundle structure and simulation results

### 4. **Console Output**
All research findings are logged to console with clear `[RESEARCH]` prefixes:

```
[RESEARCH] Starting research-only sandwich strategy
[RESEARCH] Tokens map count: 1234
[RESEARCH] Filtered pools by tokens count: 567
[RESEARCH] [Block #12345678]
[RESEARCH] New pending tx added: 0x1234...
[RESEARCH] Analyzing 2 promising sandwiches
[RESEARCH] Analyzing victim tx: 0x5678...
[RESEARCH] Sandwich 0: Amount in = 1000000000000000000, Target pair = 0x9abc...
[RESEARCH] Optimized sandwich found:
[RESEARCH]   - Amount in: 500000000000000000
[RESEARCH]   - Max revenue: 25000000000000000
[RESEARCH]   - Front gas: 150000 / Back gas: 120000
[RESEARCH] Bundle broadcast simulated (no actual broadcast)
[RESEARCH] [Block #12345678] Analyzed 2 sandwiches
```

## Comparison: Research vs Execution Mode

| Feature | Research Mode | Execution Mode |
|---------|---------------|----------------|
| **Transaction Execution** | ❌ No | ✅ Yes |
| **Telegram Notifications** | ❌ No | ✅ Yes |
| **Private Keys Required** | ❌ No | ✅ Yes |
| **Risk Level** | 🟢 Zero | 🔴 High |
| **Use Case** | Research/Analysis | Live Trading |
| **Gas Costs** | ❌ None | ✅ Yes |
| **Profit/Loss** | ❌ None | ✅ Yes |

## Code Structure

The research mode is implemented through parallel structures:

### Original Code (Execution Mode)
- `Env` struct with all fields
- `Alert` struct with Telegram integration
- `Executor` struct with transaction execution
- `main_dish` function with live execution
- `run_sandwich_strategy` function

### Research Code (Research Mode)
- `ResearchEnv` struct (minimal fields)
- `ResearchAlert` struct (console logging only)
- `ResearchExecutor` struct (simulation only)
- `research_main_dish` function (analysis only)
- `run_research_sandwich_strategy` function

## Customizing Research Mode

### Adding More Analysis

You can extend the research mode by modifying the `research_main_dish` function in `src/sandwich/main_dish.rs`:

```rust
pub async fn research_main_dish(
    // ... existing parameters ...
) -> Result<()> {
    // Add your custom analysis here
    for (tx_hash, sandwiches) in promising_sandwiches {
        // Custom analysis logic
        analyze_sandwich_economics(&sandwiches);
        calculate_risk_metrics(&sandwiches);
        export_to_csv(&sandwiches);
    }
    Ok(())
}
```

### Adding Data Export

You can add data export functionality to save research results:

```rust
use std::fs::OpenOptions;
use std::io::Write;

// In research_main_dish function
let mut file = OpenOptions::new()
    .create(true)
    .append(true)
    .open("sandwich_research.csv")?;

writeln!(file, "{},{},{},{}", 
    block_number, tx_hash, sandwich.amount_in, sandwich.max_revenue)?;
```

## Running Both Modes

You can run both modes simultaneously by:

1. **Terminal 1 (Research Mode):**
```bash
export RESEARCH_MODE=true
cargo run
```

2. **Terminal 2 (Execution Mode):**
```bash
export RESEARCH_MODE=false
cargo run
```

## Troubleshooting

### Common Issues

1. **"Missing environment variables"**
   - Research mode only needs `HTTPS_URL` and `WSS_URL`
   - Remove or comment out other env vars

2. **"Function not found"**
   - Make sure you're using the latest code with research mode
   - Check that all research functions are properly imported

3. **"No output"**
   - Check that `RESEARCH_MODE=true` is set
   - Verify your RPC endpoints are working
   - Check log level settings

### Debug Mode

Enable debug mode for more detailed output:

```env
DEBUG=true
RESEARCH_MODE=true
```

## Contributing to Research Mode

When adding new features to research mode:

1. **Keep original code intact** - add parallel structures
2. **Use `[RESEARCH]` prefix** for all log messages
3. **Document new features** in this README
4. **Test thoroughly** before committing

## License

Same as the main Sandooo project. 