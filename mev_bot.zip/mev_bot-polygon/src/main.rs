use anyhow::Result;
use ethers::providers::{Provider, Ws};
use log::info;
use std::sync::Arc;
use tokio::sync::broadcast::{self, Sender};
use tokio::task::JoinSet;
use sandooo::common::constants::{Env, ResearchEnv};
use sandooo::common::fastlane::{ stream_fastlane_opportunity_txs};
use sandooo::common::streams::{stream_new_blocks, stream_pending_transactions, Event};
use sandooo::common::utils::setup_logger;
use sandooo::sandwich::strategy::{run_research_sandwich_strategy_polygon, run_sandwich_strategy};

//ADAPTING TO POLYGON
#[tokio::main]
async fn main() -> Result<()> {
    dotenv::dotenv().ok();
    setup_logger().unwrap();

    info!("Starting Sandooo");

    // Check if we want to run in research mode
    let research_mode = std::env::var("RESEARCH_MODE")
        .unwrap_or("true".to_string())
        .parse::<bool>()
        .unwrap_or(false);

    let mut set = JoinSet::new();

    if research_mode {
        info!("Starting in RESEARCH MODE - no transactions will be executed");
        let env = ResearchEnv::new();
        let ws = Ws::connect(env.wss_url.clone()).await.unwrap();
        let provider = Arc::new(Provider::new(ws));
        let (event_sender, _): (Sender<Event>, _) = broadcast::channel(512);
        // let provider = make_polygon_provider().await?;
        // Spawn the stream task; you can keep using `provider` for other calls.
        
        // Keep the main task alive
        // loop {
            
        //     sleep(Duration::from_secs(60)).await
        // }
        

        set.spawn(stream_fastlane_opportunity_txs(event_sender.clone()));
        set.spawn(stream_pending_transactions(provider.clone(),event_sender.clone()));
        // set.spawn(stream_new_blocks(provider.clone(), event_sender.clone()));
        info!("Streaming new blocks...");
        info!("Streaming pending transactions...");
        set.spawn(run_research_sandwich_strategy_polygon(
            provider.clone(),
            event_sender.clone(),
        ));
        info!("Running RESEARCH sandwich strategy...");
    } else {
        info!("Starting in EXECUTION MODE - transactions will be executed");
        let env = Env::new();
        let ws = Ws::connect(env.wss_url.clone()).await.unwrap();
        let provider = Arc::new(Provider::new(ws));
        let (event_sender, _): (Sender<Event>, _) = broadcast::channel(512);

        set.spawn(stream_new_blocks(provider.clone(), event_sender.clone()));
        info!("Streaming new blocks...");
        set.spawn(stream_pending_transactions(
            provider.clone(),
            event_sender.clone(),
        ));
        info!("Streaming pending transactions...");
        set.spawn(run_sandwich_strategy(
            provider.clone(),
            event_sender.clone(),
        ));
        info!("Running EXECUTION sandwich strategy...");
    }

    while let Some(res) = set.join_next().await {
        info!("{:?}", res);
    }

    Ok(())
}
