use bounded_vec_deque::BoundedVecDeque;
use ethers::signers::{LocalWallet, Signer};
use ethers::types::Address;
use ethers::{
    providers::{Middleware, Provider, Ws},
    types::{BlockNumber, H160, H256, U256, U64},
};
use log::{info, warn};
use std::fs;
use std::{collections::HashMap, str::FromStr, sync::Arc};
use tokio::sync::broadcast::Sender;
use tokio::sync::Mutex;

use crate::common::alert::Alert;
use crate::common::constants::{Env, DEX_ADDRS};
use crate::common::execution::Executor;
use crate::common::pools::{load_all_pools, Pool};
use crate::common::quickswap::QUICKSWAP_ROUTER_ADDR;
use crate::common::streams::{Event, Mempool, NewBlock, NewPendingTx};
use crate::common::token_info::{TokenCache, TokenInfo};
use crate::common::tokens::load_all_tokens;
use crate::common::utils::calculate_next_block_base_fee;
use crate::sandwich::appetizer::appetizer;
use crate::sandwich::main_dish::main_dish;
use crate::sandwich::simulation::{
    extract_swap_info, extract_swap_info_polygon_with_cache, PendingTxInfo, Sandwich,
};

pub async fn run_sandwich_strategy(provider: Arc<Provider<Ws>>, event_sender: Sender<Event>) {
    let env = Env::new();

    let (pools, prev_pool_id) = load_all_pools(env.wss_url.clone(), 100000000, 50000)
        .await
        .unwrap();

    let block_number = provider.get_block_number().await.unwrap();
    let tokens_map = load_all_tokens(&provider, block_number, &pools, prev_pool_id)
        .await
        .unwrap();
    info!("Tokens map count: {:?}", tokens_map.len());

    // filter pools that don't have both token0 / token1 info
    let pools_vec: Vec<Pool> = pools
        .into_iter()
        .filter(|p| {
            let token0_exists = tokens_map.contains_key(&p.token0);
            let token1_exists = tokens_map.contains_key(&p.token1);
            token0_exists && token1_exists
        })
        .collect();
    info!("Filtered pools by tokens count: {:?}", pools_vec.len());

    let pools_map: HashMap<H160, Pool> = pools_vec
        .clone()
        .into_iter()
        .map(|p| (p.address, p))
        .collect();

    let block = provider
        .get_block(BlockNumber::Latest)
        .await
        .unwrap()
        .unwrap();
    let mut new_block = NewBlock {
        block_number: block.number.unwrap(),
        base_fee: block.base_fee_per_gas.unwrap(),
        next_base_fee: calculate_next_block_base_fee(
            block.gas_used,
            block.gas_limit,
            block.base_fee_per_gas.unwrap(),
        ),
    };

    let alert = Alert::new();
    let executor = Executor::new(provider.clone());

    let bot_address = H160::from_str(&env.bot_address).unwrap();
    let wallet = env
        .private_key
        .parse::<LocalWallet>()
        .unwrap()
        .with_chain_id(1 as u64);
    let owner = wallet.address();

    let mut event_receiver = event_sender.subscribe();

    let mut pending_txs: HashMap<H256, PendingTxInfo> = HashMap::new();
    let mut promising_sandwiches: HashMap<H256, Vec<Sandwich>> = HashMap::new();
    let mut simulated_bundle_ids = BoundedVecDeque::new(30);

    loop {
        match event_receiver.recv().await {
            Ok(event) => match event {
                Event::Block(block) => {
                    new_block = block;
                    info!("[Block #{:?}]", new_block.block_number);

                    // remove confirmed transactions
                    let block_with_txs = provider
                        .get_block_with_txs(new_block.block_number)
                        .await
                        .unwrap()
                        .unwrap();

                    let txs: Vec<H256> = block_with_txs
                        .transactions
                        .into_iter()
                        .map(|tx| tx.hash)
                        .collect();

                    for tx_hash in &txs {
                        if pending_txs.contains_key(tx_hash) {
                            // Remove any pending txs that have been confirmed
                            let _removed = pending_txs.remove(tx_hash).unwrap();
                            promising_sandwiches.remove(tx_hash);
                            // info!(
                            //     "⚪️ V{:?} TX REMOVED: {:?} / Pending txs: {:?}",
                            //     _removed.touched_pairs.get(0).unwrap().version,
                            //     tx_hash,
                            //     pending_txs.len()
                            // );
                        }
                    }

                    // remove pending txs older than 5 blocks
                    pending_txs.retain(|_, v| {
                        (new_block.block_number - v.pending_tx.added_block.unwrap()) < U64::from(3)
                    });
                    promising_sandwiches.retain(|h, _| pending_txs.contains_key(h));
                }
                Event::PendingTx(mut pending_tx) => {
                    let tx_hash = pending_tx.tx.hash;
                    let already_received = pending_txs.contains_key(&tx_hash);

                    let mut should_add = false;

                    if !already_received {
                        let tx_receipt = provider.get_transaction_receipt(tx_hash).await;
                        match tx_receipt {
                            Ok(receipt) => match receipt {
                                Some(_) => {
                                    // returning a receipt means that the tx is confirmed
                                    // should not be in pending_txs
                                    pending_txs.remove(&tx_hash);
                                }
                                None => {
                                    should_add = true;
                                }
                            },
                            _ => {}
                        }
                    }

                    let mut victim_gas_price = U256::zero();

                    match pending_tx.tx.transaction_type {
                        Some(tx_type) => {
                            if tx_type == U64::zero() {
                                victim_gas_price = pending_tx.tx.gas_price.unwrap_or_default();
                                should_add = victim_gas_price >= new_block.base_fee;
                            } else if tx_type == U64::from(2) {
                                victim_gas_price =
                                    pending_tx.tx.max_fee_per_gas.unwrap_or_default();
                                should_add = victim_gas_price >= new_block.base_fee;
                            }
                        }
                        _ => {}
                    }

                    let swap_info = if should_add {
                        match extract_swap_info(&provider, &new_block, &pending_tx, &pools_map)
                            .await
                        {
                            Ok(swap_info) => swap_info,
                            Err(e) => {
                                warn!("extract_swap_info error: {e:?}");
                                Vec::new()
                            }
                        }
                    } else {
                        Vec::new()
                    };

                    if swap_info.len() > 0 {
                        pending_tx.added_block = Some(new_block.block_number);
                        let pending_tx_info = PendingTxInfo {
                            pending_tx: pending_tx.clone(),
                            touched_pairs: swap_info.clone(),
                        };
                        pending_txs.insert(tx_hash, pending_tx_info.clone());
                        // info!(
                        //     "🔴 V{:?} TX ADDED: {:?} / Pending txs: {:?}",
                        //     removed.touched_pairs.get(0).unwrap().version,
                        //     tx_hash,
                        //     pending_txs.len()
                        // );

                        match appetizer(
                            &provider,
                            &new_block,
                            tx_hash,
                            victim_gas_price,
                            &pending_txs,
                            &mut promising_sandwiches,
                        )
                        .await
                        {
                            Err(e) => warn!("appetizer error: {e:?}"),
                            _ => {}
                        }

                        if promising_sandwiches.len() > 0 {
                            match main_dish(
                                &provider,
                                &alert,
                                &executor,
                                &new_block,
                                owner,
                                bot_address,
                                U256::from(9900), // 99%
                                &promising_sandwiches,
                                &mut simulated_bundle_ids,
                                &pending_txs,
                            )
                            .await
                            {
                                Err(e) => warn!("main_dish error: {e:?}"),
                                _ => {}
                            }
                        }
                    }
                }
            },
            _ => {}
        }
    }
}

#[inline]
pub fn is_pending_dex_tx(pending_tx: &NewPendingTx) -> bool {
    let tx = &pending_tx.tx;
    tx.block_number.is_none() && tx.to.map(|a| DEX_ADDRS.contains(&a)).unwrap_or(false)
}

/// Research-only version of the sandwich strategy that analyzes opportunities without executing them
pub async fn run_research_sandwich_strategy_polygon(
    provider: Arc<Provider<Ws>>,
    event_sender: Sender<Event>,
) {
    let env = crate::common::constants::ResearchEnv::new();
    let token_cache_path = "tokens.json";

    // Load the token cache from file at startup, or create an empty one.
    let initial_cache: HashMap<Address, TokenInfo> = fs::read_to_string(token_cache_path)
        .map(|data| serde_json::from_str(&data).unwrap_or_default())
        .unwrap_or_default();

    info!("Loaded {} tokens from cache.", initial_cache.len());

    let token_cache: TokenCache = Arc::new(Mutex::new(initial_cache));

    //Pools to have best option for abckrun
    let (pools, prev_pool_id) = load_all_pools(env.wss_url.clone(), 100000000, 50000)
        .await
        .unwrap();

    let block_number = provider.get_block_number().await.unwrap();
    // let tokens_map = load_all_tokens(&provider, block_number, &pools, prev_pool_id)
    //     .await
    //     .unwrap();
    // info!("[RESEARCH] Tokens map count: {:?}", tokens_map.len());

    // filter pools that don't have both token0 / token1 info
    // let pools_vec: Vec<Pool> = pools
    //     .into_iter()
    //     .filter(|p| {
    //         let token0_exists = tokens_map.contains_key(&p.token0);
    //         let token1_exists = tokens_map.contains_key(&p.token1);
    //         token0_exists && token1_exists
    //     })
    //     .collect();
    // info!(
    //     "[RESEARCH] Filtered pools by tokens count: {:?}",
    //     pools_vec.len()
    // );

    // let pools_map: HashMap<H160, Pool> = pools_vec
    //     .clone()
    //     .into_iter()
    //     .map(|p| (p.address, p))
    //     .collect();

    let block = provider
        .get_block(BlockNumber::Latest)
        .await
        .unwrap()
        .unwrap();
    let mut new_block = NewBlock {
        block_number: block.number.unwrap(),
        base_fee: block.base_fee_per_gas.unwrap(),
        next_base_fee: calculate_next_block_base_fee(
            block.gas_used,
            block.gas_limit,
            block.base_fee_per_gas.unwrap(),
        ),
    };

    let alert = Alert::new();
    let executor = Executor::new_dummy(provider.clone());

    // In research mode, we don't need bot addresses or private keys
    let dummy_bot_address = H160::zero();
    let dummy_owner = H160::zero();

    let mut event_receiver = event_sender.subscribe();

    let mut pending_txs: HashMap<H256, PendingTxInfo> = HashMap::new();
    let mut promising_sandwiches: HashMap<H256, Vec<Sandwich>> = HashMap::new();
    let mut simulated_bundle_ids = BoundedVecDeque::new(30);

    info!("[RESEARCH] Starting research-only sandwich strategy");

    loop {
        match event_receiver.recv().await {
            Ok(event) => match event {
                //This is consuming useless rpc calls
                Event::Block(block) => {
                    new_block = block;
                    info!("[RESEARCH] [Block #{:?}]", new_block.block_number);

                    // remove pending txs older than 5 blocks
                    pending_txs.retain(|_, v| {
                        (new_block.block_number - v.pending_tx.added_block.unwrap()) < U64::from(3)
                    });
                    promising_sandwiches.retain(|h, _| pending_txs.contains_key(h));
                }
                Event::PendingTx(mut pending_tx) => {
                    // info!("[RESEARCH] Pending tx: {:?}", pending_tx.tx.hash);
                    let tx_hash = pending_tx.tx.hash;
                    let already_received = pending_txs.contains_key(&tx_hash);

                    if !already_received {
                        //Check values if from public mempool
                        if matches!(pending_tx.origin, Mempool::Ethereum | Mempool::Polygon) {
                            let tx_receipt = provider.get_transaction_receipt(tx_hash).await;

                            match tx_receipt {
                                Ok(receipt) => {
                                    match receipt {
                                        Some(_) => {
                                            // returning a receipt means that the tx is confirmed
                                            // should not be in pending_txs
                                            let added_block_number =
                                                receipt.unwrap().block_number.unwrap();
                                            info!("[RESEARCH] Confirmed tx removed: {:?}, latency issue", tx_hash);
                                            pending_tx.added_block = Some(added_block_number);
                                            pending_txs.remove(&tx_hash);
                                        }
                                        None => {
                                            // info!("[RESEARCH] Pending tx: {:?} should be added", tx_hash);
                                            //This is
                                        }
                                    }
                                }
                                _ => {}
                            }
                        }
                    }

                    let victim_gas_price = pending_tx.tx.gas_price.unwrap_or_else(|| {
                        info!("Failed getting gas price");
                        U256::one()
                    });

                    if !(is_pending_dex_tx(&pending_tx)
                        && pending_tx.tx.to == Some(*QUICKSWAP_ROUTER_ADDR))
                    {
                        continue;
                    }

                    //Removed the pools argument
                    let swap_info =match extract_swap_info_polygon_with_cache(
                        &provider,
                        &new_block,
                        &pending_tx,
                        &token_cache,
                    )
                    .await
                    {
                        Ok(swap_info) => {
                            if swap_info.len() != 0 {
                                // info!("SwapInfo gotten succesfully");
                                info!("{:?}", swap_info);
                            }
                            swap_info
                        }
                        Err(e) => {
                            warn!("[RESEARCH] extract_swap_info_polygon error: {e:?}");
                            continue;
                        }
                    };

                    if swap_info.len() > 0 {
                        pending_tx.added_block = Some(new_block.block_number);
                        let pending_tx_info = PendingTxInfo {
                            pending_tx: pending_tx.clone(),
                            touched_pairs: swap_info.clone(),
                        };
                        pending_txs.insert(tx_hash, pending_tx_info.clone());
                        info!(
                            "[RESEARCH] New pending tx added for appetizer: {:?}",
                            tx_hash
                        );

                        //If the direction is sell, it skips and continues, why most sandwches aren't profitable
                        match appetizer(
                            &provider,
                            &new_block,
                            tx_hash,
                            victim_gas_price,
                            &pending_txs,
                            &mut promising_sandwiches,
                        )
                        .await
                        {
                            Err(e) => warn!("[RESEARCH] appetizer error: {e:?}"),
                            _ => {
                                info!("Appetizer research passed")
                            }
                        }
                        println!("Researching main dish...");
                        if promising_sandwiches.len() > 0 {
                            match crate::sandwich::main_dish::main_dish_polygon(
                                &provider,
                                &alert,
                                &executor,
                                &new_block,
                                dummy_owner,
                                dummy_bot_address,
                                U256::from(9900), // 99%
                                &promising_sandwiches,
                                &mut simulated_bundle_ids,
                                &pending_txs,
                                false,
                            )
                            .await
                            {
                                Err(e) => warn!("[RESEARCH] research_main_dish error: {e:?}"),
                                _ => {
                                    println!("Research main dish passed");
                                }
                            }
                        } else {
                            info!("No promising sandwiches");
                        }
                    }
                }
            },
            _ => {}
        }
    }
}
