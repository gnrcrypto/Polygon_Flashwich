use std::collections::HashSet;

use ethers::types::Address;
use once_cell::sync::Lazy;

pub static PROJECT_NAME: &str = "sandooo";

pub fn get_env(key: &str) -> String {
    std::env::var(key).unwrap_or(String::from(""))
}

#[derive(Debug, Clone)]
pub struct Env {
    pub https_url: String,
    pub wss_url: String,
    pub bot_address: String,
    pub private_key: String,
    pub identity_key: String,
    pub telegram_token: String,
    pub telegram_chat_id: String,
    pub use_alert: bool,
    pub debug: bool,
}

impl Env {
    pub fn new() -> Self {
        Env {
            https_url: get_env("HTTPS_URL"),
            wss_url: get_env("WSS_URL"),
            bot_address: get_env("BOT_ADDRESS"),
            private_key: get_env("PRIVATE_KEY"),
            identity_key: get_env("IDENTITY_KEY"),
            telegram_token: get_env("TELEGRAM_TOKEN"),
            telegram_chat_id: get_env("TELEGRAM_CHAT_ID"),
            use_alert: get_env("USE_ALERT").parse::<bool>().unwrap(),
            debug: get_env("DEBUG").parse::<bool>().unwrap(),
        }
    }
}

/// Research-only environment configuration (no execution, no notifications)
#[derive(Debug, Clone)]
pub struct ResearchEnv {
    pub https_url: String,
    pub wss_url: String,
    pub debug: bool,
}

impl ResearchEnv {
    pub fn new() -> Self {
        ResearchEnv {
            https_url: get_env("HTTPS_URL"),
            wss_url: get_env("WSS_URL"),
            debug: get_env("DEBUG").parse::<bool>().unwrap_or(false),
        }
    }
}

pub static COINBASE: &str = "0xDAFEA492D9c6733ae3d56b7Ed1ADB60692c98Bc5"; // Flashbots Builder

pub static WETH: &str = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2";
pub static USDT: &str = "0xdAC17F958D2ee523a2206206994597C13D831ec7";
pub static USDC: &str = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48";

/*
Can figure out the balance slot of ERC-20 tokens using the:
EvmSimulator::get_balance_slot method

However, note that this does not work for all tokens.
Especially tokens that are using proxy patterns.
*/
pub static WETH_BALANCE_SLOT: i32 = 3;
pub static USDT_BALANCE_SLOT: i32 = 2;
pub static USDC_BALANCE_SLOT: i32 = 9;

pub static WETH_DECIMALS: u8 = 18;
pub static USDT_DECIMALS: u8 = 6;
pub static USDC_DECIMALS: u8 = 6;


// Polygon (PoS) mainnet

pub const WETH_POLYGON: &str          = "0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619"; // WETH
pub const USDT_POLYGON: &str          = "0xC2132D05D31c914a87C6611C10748AEb04B58e8F"; // USDT
pub const USDC_POLYGON_BRIDGED: &str  = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"; // USDC.e (bridged)
pub const USDC_POLYGON_NATIVE: &str   = "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359"; // USDC (native by Circle)
pub const WMATIC: &str                = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"; // Wrapped MATIC
pub const MATIC_NATIVE: &str          = "0x0000000000000000000000000000000000001010"; // native MATIC pseudo-address (not ERC-20)
pub const DAI_POLYGON: &str           = "0x8f3cf7ad23cd3cadbd9735aff958023239c6a063";

pub static DEX_ADDRS: Lazy<HashSet<Address>> = Lazy::new(|| {
    [
        // QuickSwap V2 (UniswapV2 fork)
        "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff", // Router V2
        "0x5757371414417b8C6CAad45bAeF941aBc7d3Ab32", // Factory V2
        // SushiSwap (V2-style)
        "0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506", // Sushi Router
        // Uniswap v3 (Polygon)
        "0xE592427A0AEce92De3Edee1F18E0157C05861564", // SwapRouter
        "0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45", // SwapRouter02
        "0x61fFE014bA17989E743c5F6cB21bF9697530B21e", // QuoterV2
        "0x1095692A6237d83C6a72F3F5eFEdb9A670C49223", // UniversalRouter
        // Balancer V2 (same vault addr on many chains)
        "0xBA12222222228d8Ba445958a75a0704d566BF2C8", // Vault
        // Curve router (RouterNG on Polygon)
        "0x0DCDED3545D565bA3B19E683431381007245d983",
        // 1inch Aggregation Router v5 (same across chains except zkSync)
        "0x1111111254EEB25477B68fb85Ed929f73A960582",
        // 0x Exchange Proxy (Exchange V4 / Settler entrypoint)
        "0xDef1C0ded9bec7F1a1670819833240f027b25EfF",
        // KyberSwap Aggregator (Polygon meta router labels)
        "0x19319c9744e8de0205d43e4a3f5c5387a95fd171",
        "0x6131b5fae19ea4f9d964eac0408e4408b66337b5",
        // DODO V2 (Polygon proxies)
        "0x45894C062E6f4E58B257e0826675355305dfef0d", // DODOV2Proxy
        "0xfDDCA6ffCE24dF5bE3e8AaD32081822f86178048", // DSPProxy
        "0x53eE28b9F0A6416857C1e7503032E27e80F52DA0", // RouteProxy
    ]
    .into_iter()
    .map(|s| s.parse::<Address>().unwrap())
    .collect()
});
