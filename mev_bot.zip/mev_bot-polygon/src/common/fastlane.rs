use ethers::utils::{hex, keccak256};
use anyhow::Result;
use ethers::prelude::*;
use futures::{StreamExt, SinkExt};
use rlp::{DecoderError, Rlp, RlpStream};
use std::time::Duration;
use tokio::{sync::broadcast::Sender, time::sleep};
use tokio_tungstenite::tungstenite::Message;
use crate::common::streams::{Event, Mempool, NewPendingTx};
use anyhow::anyhow;
// ==== FastLane Polygon WS ====
pub const FASTLANE_WS: &str = "wss://polygon-rpc.fastlane.xyz/ws";


/// Spawnable task: connect to FastLane, subscribe to `opportunityTxs`,
/// and forward each opportunity as `Event::PendingTx` via `tx_events`.
pub async fn stream_fastlane_opportunity_txs(
    tx_events: Sender<Event>,
) {
    let mut attempt = 0u32;

    loop {
        attempt += 1;
        match subscribe_once( tx_events.clone()).await {
            Ok(()) => {
                // graceful close (unlikely); short delay then reconnect
                sleep(Duration::from_secs(1)).await;
            }
            Err(e) => {
                eprintln!("[fastlane] ws error (attempt {attempt}): {e:#}");
                // backoff up to ~10s
                let backoff = attempt.min(10) as u64;
                sleep(Duration::from_secs(backoff)).await;
            }
        }
    }
}

/// One connection lifecycle: open → subscribe → stream → exit on close/error.
async fn subscribe_once(
    tx_events: Sender<Event>,
) -> Result<()> {
    // IMPORTANT: pass &str (not Url) to avoid IntoClientRequest version clashes
    let (mut ws, _resp) = tokio_tungstenite::connect_async(FASTLANE_WS).await?;

    // Subscribe to the topic
    let sub = r#"{"jsonrpc":"2.0","id":1,"method":"subscribe","params":["opportunityTxs"]}"#;
    ws.send(Message::Text(sub.into())).await?;

    while let Some(msg) = ws.next().await {
        match msg {
            Ok(Message::Text(txt)) => {
                if let Ok(v) = serde_json::from_str::<serde_json::Value>(&txt) {
                    if let Some(raw_hex) = extract_opportunity_raw(&v) {
                        // Build a Transaction (hydrated from node if possible; stub fallback)
                        match decode_raw_signed_tx(&raw_hex){
                            Ok(tx) => {
                                let new_pending_tx = NewPendingTx {
                                    added_block: None,
                                    tx,
                                    origin: Mempool::Fastlane
                                };
                                // println!("[FASTLANE] New tx for auction {:?}", new_pending_tx);
                                let _ = tx_events.send(Event::PendingTx(new_pending_tx));
                            }
                            Err(e) => {
                                eprintln!("[fastlane] could not build tx from raw: {e:#}");
                                eprint!("[FASTLANE], raw hex output: {:?}", raw_hex);
                            }
                        }
                    } else {
                        // Not an opportunity payload; you can log if you like
                        println!("[fastlane] msg: {v}");
                    }
                } else {
                    // Unexpected text payload
                    println!("[fastlane] text: {txt}");
                }
            }
            Ok(Message::Binary(_bin)) => {
                // ignore (not used currently)
            }
            Ok(Message::Ping(p)) => {
                // keep-alive
                let _ = ws.send(Message::Pong(p)).await;
            }
            Ok(Message::Pong(_)) => {}
            Ok(Message::Close(c)) => {
                println!("[fastlane] close: {c:?}");
                break;
            }
            Ok(_)=> {
                println!("Unknown message received");
            }
            Err(e) => {
                eprintln!("[fastlane] socket error: {e:#}");
                break;
            }
        }
    }
    Ok(())
}

/// Extract the raw signed tx hex from a FastLane WS message.
/// Matches the shape seen via `wscat`:
/// {"jsonrpc":"2.0","method":"subscribe","params":{"result":"0x..","subscription":"opportunityTxs"}}
fn extract_opportunity_raw(v: &serde_json::Value) -> Option<&str> {
    let params = v.get("params")?;
    if params.get("subscription")?.as_str()? != "opportunityTxs" {
        return None;
    }
    params.get("result")?.as_str()
}

// ========== RAW TX DECODER (EIP-1559 0x02) ==========
pub fn decode_raw_signed_tx(raw_hex: &str) -> Result<Transaction> {
    let raw = raw_hex.strip_prefix("0x").unwrap_or(raw_hex);
    let bytes = hex::decode(raw)?;
    if bytes.is_empty() {
        return Err(anyhow!("empty raw tx"));
    }

    match bytes[0] {
        0x02 => decode_eip1559(&bytes),
        0x01 => Err(anyhow!("EIP-2930 (0x01) decoder not implemented")),
        _    => decode_legacy(&bytes), // best-effort legacy fallback
    }
}

fn decode_eip1559(bytes: &[u8]) -> Result<Transaction> {
    // 0x02 || rlp([chainId, nonce, maxPriorityFeePerGas, maxFeePerGas, gasLimit,
    //             to, value, data, accessList, yParity, r, s])
    let rlp = Rlp::new(&bytes[1..]); // skip the 0x02 type byte
    if !rlp.is_list() {
        return Err(anyhow!("malformed 1559 rlp root"));
    }

    // --- Fields ---
    let chain_id: U256                = rlp.val_at(0)?;
    let nonce: U256                   = rlp.val_at(1)?;
    let max_prio_fee: U256            = rlp.val_at(2)?;
    let max_fee: U256                 = rlp.val_at(3)?;
    let gas_limit: U256               = rlp.val_at(4)?;

    // to: may be empty for contract creations
    let to_opt: Option<Address> = {
        let n = rlp.at(5)?;
        if n.is_empty() { None } else { Some(n.as_val()?) }
    };

    let value: U256                   = rlp.val_at(6)?;
    let input: Bytes                  = Bytes::from(rlp.val_at::<Vec<u8>>(7)?);
    let access_list                   = decode_access_list(rlp.at(8)?)?;

    // signature
    let y_parity: u8                  = rlp.val_at(9)?;
    let r: U256                       = rlp.val_at(10)?;
    let s: U256                       = rlp.val_at(11)?;

    // --- tx hash = keccak256(full encoded bytes, including 0x02) ---
    let tx_hash = H256::from_slice(&keccak256(bytes));

    // --- recover from address ---
    let sighash = eip1559_signing_hash(chain_id, nonce, max_prio_fee, max_fee, gas_limit, to_opt, value, &input, &access_list)?;
    let sig = Signature { r, s, v: y_parity as u64 };
    let from = sig.recover(sighash)?;

    // --- fill ethers::types::Transaction ---
    let mut tx = Transaction::default();
    tx.hash = tx_hash;
    tx.from = from;
    tx.to = to_opt;
    tx.nonce = nonce;
    tx.gas = gas_limit;
    tx.max_priority_fee_per_gas = Some(max_prio_fee);
    tx.max_fee_per_gas = Some(max_fee);
    tx.value = value;
    tx.input = input;
    tx.chain_id = Some(U256::from(chain_id.as_u64())); // Polygon=137
    tx.v = U64::from(y_parity); // 0/1 for 1559
    tx.r = r;
    tx.s = s;
    tx.transaction_type = Some(U64::from(2u64));
    tx.access_list = Some(access_list);

    Ok(tx)
}

fn eip1559_signing_hash(
    chain_id: U256,
    nonce: U256,
    max_prio_fee: U256,
    max_fee: U256,
    gas_limit: U256,
    to: Option<Address>,
    value: U256,
    input: &Bytes,
    access_list: &transaction::eip2930::AccessList,
) -> Result<H256> {
    // RLP encode the *signing payload* (no yParity/r/s), then prefix 0x02 and keccak
    let mut s = RlpStream::new_list(9);
    s.append(&chain_id);
    s.append(&nonce);
    s.append(&max_prio_fee);
    s.append(&max_fee);
    s.append(&gas_limit);
    match to {
        Some(addr) => s.append(&addr),
        None => s.append_empty_data(), // contract creation
    };
    s.append(&value);
    s.append(&input.0);
    encode_access_list(&mut s, access_list);

    let bytes_slice = s.out();
    let mut preimage = Vec::with_capacity(1 + &bytes_slice.len());
    preimage.push(0x02u8);
    preimage.extend_from_slice(&bytes_slice);
    Ok(H256::from_slice(&keccak256(&preimage)))
}

fn decode_access_list(node: rlp::Rlp) -> Result<transaction::eip2930::AccessList, DecoderError> {
    use transaction::eip2930::{AccessList, AccessListItem};
    let mut out: AccessList = vec![].into();
    for i in 0..node.item_count().unwrap_or(0) {
        let item = node.at(i)?;
        let address: Address = item.val_at(0)?;
        let keys_node = item.at(1)?;
        let mut storage_keys: Vec<H256> = Vec::new();
        for j in 0..keys_node.item_count().unwrap_or(0) {
            storage_keys.push(keys_node.val_at(j)?);
        }
        out.0.push(AccessListItem { address, storage_keys });
    }
    Ok(out)
}

fn encode_access_list(s: &mut RlpStream, al: &transaction::eip2930::AccessList) {
    use transaction::eip2930::AccessListItem;
    s.begin_list(al.0.len());
    for AccessListItem { address, storage_keys } in &al.0 {
        s.begin_list(2);
        s.append(address);
        s.begin_list(storage_keys.len());
        for key in storage_keys {
            s.append(key);
        }
    }
}




fn decode_legacy(bytes: &[u8]) -> Result<Transaction> {
    // Full raw hash (what explorers show)
    let tx_hash = H256::from_slice(&keccak256(bytes));

    let rlp = Rlp::new(bytes);
    if !rlp.is_list() {
        return Err(anyhow!("malformed legacy rlp root"));
    }

    // legacy fields: [nonce, gasPrice, gasLimit, to, value, data, v, r, s]
    let nonce: U256      = rlp.val_at(0)?;
    let gas_price: U256  = rlp.val_at(1)?;
    let gas_limit: U256  = rlp.val_at(2)?;

    // `to` can be empty for contract creation
    let to_opt: Option<Address> = {
        let n = rlp.at(3)?;
        if n.is_empty() { None } else { Some(n.as_val()?) }
    };

    let value: U256      = rlp.val_at(4)?;
    let input: Bytes     = Bytes::from(rlp.val_at::<Vec<u8>>(5)?);

    // signature parts
    let v_u256: U256     = rlp.val_at(6)?;
    let r: U256          = rlp.val_at(7)?;
    let s: U256          = rlp.val_at(8)?;

    // EIP-155 chain_id derivation: if v >= 35, chain_id = (v - 35) / 2
    let chain_id_opt = if v_u256 >= U256::from(35u64) {
        Some(((v_u256 - U256::from(35u64)) / U256::from(2u64)).as_u64())
    } else {
        None
    };

    // Normalize v to {27,28} for recovery
    let v_norm: u64 = if let Some(cid) = chain_id_opt {
        // v = 35 + 2*chainId + parity(0/1)
        let parity = ((v_u256 - U256::from(35u64) - U256::from(2u64 * cid)) & U256::one()).as_u64();
        27 + parity
    } else {
        // pre-EIP155: v is already 27/28 (or 0/1 in some rare cases)
        let v = v_u256.as_u64();
        if v == 0 || v == 1 { 27 + v } else { v }
    };

    // Signing hash (EIP-155 aware)
    let sighash = legacy_signing_hash(
        nonce,
        gas_price,
        gas_limit,
        to_opt,
        value,
        &input,
        chain_id_opt,
    );

    // Recover sender
    let sig = Signature { r, s, v: v_norm };
    let from = sig.recover(sighash)?;

    // Build ethers::types::Transaction
    let mut tx = Transaction::default();
    tx.hash = tx_hash;
    tx.from = from;
    tx.to = to_opt;
    tx.nonce = nonce;
    tx.gas = gas_limit;
    tx.gas_price = Some(gas_price);
    tx.value = value;
    tx.input = input;
    tx.v = U64::from(v_u256.as_u64());
    tx.r = r;
    tx.s = s;
    tx.transaction_type = None;                 // legacy
    tx.chain_id = chain_id_opt.map(U256::from);  // Some(137) on Polygon most of the time
    // access_list/max fees remain None for legacy

    Ok(tx)
}

fn legacy_signing_hash(
    nonce: U256,
    gas_price: U256,
    gas_limit: U256,
    to: Option<Address>,
    value: U256,
    input: &Bytes,
    chain_id_opt: Option<u64>,
) -> H256 {
    let mut s = if chain_id_opt.is_some() { RlpStream::new_list(9) } else { RlpStream::new_list(6) };
    s.append(&nonce);
    s.append(&gas_price);
    s.append(&gas_limit);
    match to {
        Some(addr) => s.append(&addr),
        None => s.append_empty_data(), // contract creation
    };
    s.append(&value);
    s.append(&input.0);

    if let Some(chain_id) = chain_id_opt {
        s.append(&U256::from(chain_id));
        s.append_empty_data(); // 0
        s.append_empty_data(); // 0
    }

    H256::from_slice(&keccak256(s.out()))
}
