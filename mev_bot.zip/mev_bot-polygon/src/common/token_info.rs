use ethers::prelude::*;
use serde::{Deserialize, Serialize};
use std::{collections::HashMap, sync::Arc};
use tokio::sync::Mutex;
use ethers::prelude::abi::AbiEncode;
use futures::future::join_all;

// Structure to hold all necessary token information.
// Deriving Serialize/Deserialize allows easy conversion to/from JSON.
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct TokenInfo {
    pub address: Address,
    pub name: String,
    pub symbol: String,
    pub decimals: u8,
    pub network: String,
}

// A thread-safe, shared cache for our token metadata.
pub type TokenCache = Arc<Mutex<HashMap<Address, TokenInfo>>>;



// ERC20 ABI fragments needed for the calls.
abigen!(
    MinimalTokenABI,
    r#"[
        function name() external view returns (string)
        function symbol() external view returns (string)
        function decimals() external view returns (uint8)
    ]"#
);

/// Checks a list of token addresses against the cache. For any new tokens,
/// it fetches their metadata from the blockchain and updates both the in-memory
/// cache and the `tokens.json` file.

fn is_erc20_like(addr: &Address) -> bool {
        if addr.is_zero() { return false; }
        // Polygon native MATIC pseudo-address
        if format!("{addr:?}").to_lowercase() == "0x0000000000000000000000000000000000001010" { return false; }
        // Some feeds use 0xeeee... as “native”
        let s = format!("{addr:?}").to_lowercase();
        if s == "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" { return false; }
        true
    }

pub async fn ensure_tokens_are_cached(
    provider: &Arc<Provider<Ws>>,
    token_addresses: &[Address],
    token_cache: &TokenCache,
    network_name: &str,
    cache_path: &str,
) -> anyhow::Result<()> {
    // Helper: skip non-ERC20 “addresses”
    

    let mut cache = token_cache.lock().await;

    // Pick only addresses we don’t already have & that look ERC20-like
    let mut addrs: Vec<Address> = token_addresses
        .iter()
        .copied()
        // .filter(is_erc20_like)
        .filter(|a| !cache.contains_key(a))
        .collect();

    // Dedup
    addrs.sort_unstable();
    addrs.dedup();

    if addrs.is_empty() {
        return Ok(());
    }

    // Fetch each token concurrently (no multicall — avoids ABI/tuple hassles)
    let futs = addrs.iter().map(|&a| {
        let prov = provider.clone();
        async move {
            let c = MinimalTokenABI::new(a, prov);
            // Each call can fail; provide graceful fallbacks.
            let name   = c.name().call().await.unwrap_or_else(|_| String::from("Unknown Token"));
            let symbol = c.symbol().call().await.unwrap_or_else(|_| {
                let short = format!("{a:?}");
                format!("TKN-{}", &short[2..10])
            });
            let decimals = c.decimals().call().await.unwrap_or(18u8); // sensible default
            (a, name, symbol, decimals)
        }
    });

    let results = join_all(futs).await;

    let mut new_tokens_found = false;
    for (address, name, symbol, decimals) in results {
        // Insert into cache
        cache.insert(address, TokenInfo {
            address,
            name,
            symbol,
            decimals,
            network: network_name.to_string(),
        });
        new_tokens_found = true;
    }

    // Persist to disk (cwd), only if something changed
    if new_tokens_found {
        let json = serde_json::to_string_pretty(&*cache)?;
        std::fs::write(cache_path, json)?;
        log::info!("Saved updated token cache to {}", cache_path);
        // Optional: show where it was written so you can find it
        if let Ok(cwd) = std::env::current_dir() {
            log::info!("Current working dir: {}", cwd.display());
        }
    }

    Ok(())
}

/// Retrieves a token's symbol and decimals from the shared cache.
/// Provides a fallback if the token is somehow not in the cache.
pub fn get_token_info_from_cache(
    address: Address,
    cache: &HashMap<Address, TokenInfo>,
) -> (String, u8) {
    match cache.get(&address) {
        Some(info) => (info.symbol.clone(), info.decimals),
        None => (format!("TKN-{}", &address.encode_hex()[..8]), 18), // Fallback
    }
}