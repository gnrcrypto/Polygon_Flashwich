# Sandooo

A sandwich bot

Medium articles WIP:
https://medium.com/@solidquant

Roadmap + expected release dates:
1. Opportunity detection (~1/28)
[100 Hours of Building a Sandwich Bot](https://medium.com/@solidquant/100-hours-of-building-a-sandwich-bot-a89235281da3)
2. Execution (~2/4)
[Let's See If our Sandwich Bot Really Works](https://medium.com/@solidquant/lets-see-if-our-sandwich-bot-really-works-9546c49059bd)
3. Update #1: Stablecoin sandwich (~2/18)
4. Update #2: Multiple sandwich bundling (~2/18)
[Adding Stablecoin Sandwiches and Group Bundling to improve our sandwich bot](https://medium.com/@solidquant/adding-stablecoin-sandwiches-and-group-bundling-to-improve-our-sandwich-bot-2037cf741f77)
5. Update #3: V3 implementation (~2/25)

☕ Follow me on Twitter:
https://twitter.com/solidquant

⚡️ Come join our Discord community to take this journey together:

[👨‍👩‍👦‍👦 Join the Solid Quant Discord Server!](https://discord.com/invite/e6KpjTQP98)

### This is the Polygon Fork

Polygon has faster (2s) blocktimes

# TODO
- RPC Fetch for pending txs could be done better with more async calls
- Use the OG method for getting quickswaps tx inside a contract

